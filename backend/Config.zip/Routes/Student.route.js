const {Router}=require("express")
const Authentification = require("../Middlewares/Authentification")
const LoginModel = require("../Model/Login.model")
const StudentModel = require("../Model/Student.model")

const studentController=Router()

// For teacher where he can access all student tests

studentController.get("/user/:id",async(req,res)=>{
   const id=req.params.id
  

    const FindStudent=await StudentModel.find({userid:id})

    if(FindStudent.length>0)
    {
        return res.send({messege:"Student Find Succesfull",FindStudent})
    }
    else{
        return res.send("Data not found")
    }

})
 

// For teacher to delete perticular student test

studentController.delete("/delete/:id",async(req,res)=>{
    const id=req.params.id

    const Findtest=await StudentModel.findOneAndDelete({_id:id})

    res.send({messege:"Test Deleted Suceesfuly",Findtest})
})

// For teacher to delete perticular student 

studentController.delete("/delete/:studentid",async(req,res)=>{
    const id=req.params.studentid

    const Findstudent=await LoginModel.findOneAndDelete({_id:id})

    res.send({messege:"Student Deleted Suceesfuly",Findstudent})
})

// For teacher to create perticular tests for student

studentController.post("/create/:id",async(req,res)=>{
    const {name,subject,marks,date}=req.body
    const id=req.params.id

    // const FindStudent=await LoginModel.findOne({_id:id})
    const NewTestData=new StudentModel({
        name,subject,marks,date,userid:id
    })
    NewTestData.save()
   
    res.send({messege:"Data created Succesfully",NewTestData})
})

// for Student to access his/her tests

studentController.get("/",Authentification,async(req,res)=>{
   var {userid}=req.body

   const Data=await StudentModel.find({userid})

   if(Data.length>0)
   {
       res.send(Data)
   }
   else{
      res.send("Data not found")
   }
})

module.exports=studentController