import { Switch } from "@chakra-ui/react"

const InitialState={

}

export const ReducerLogin=(state=InitialState,{type,payload})=>{
    switch(type){
        default:{
            return state
        }
    }
}