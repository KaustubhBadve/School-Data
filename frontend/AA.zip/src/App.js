import logo from './logo.svg';
import './App.css';
import MainRouting from './Mainrouting/MainRouting';

function App() {
  return (
    <div className="App">
         <MainRouting/>
    </div>
  );
}

export default App;
