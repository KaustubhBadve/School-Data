import { Box, Button, Td, Tr, useToast } from "@chakra-ui/react";
import React from "react";
import { useDispatch } from "react-redux";
import {
  deleteStudentData,
  getStudentData,
} from "../Redux/Student/Action.type";
import CreateTest from "./CreateTest";
import { StudenttestModal } from "./StudenttestModal";

const TeacherTable = ({ e, i }) => {
  const toast = useToast({ position: "top" });
  const dispatch = useDispatch();

  const HandleDelete = (id) => {
    dispatch(deleteStudentData(id));
    toast({
      title: "Student Deleted Succesfull",
      status: "success",
      duration: 5000,
      isClosable: true,
    });
    dispatch(getStudentData());
  };

  return (
    <Tr>
      <Td>{i + 1}</Td>
      <Td>{e.name}</Td>
      <Td>{e.gender}</Td>
      <Td>{e.age}</Td>
      <Td>{e.email}</Td>
      <Td>
        <StudenttestModal e={e} />
      </Td>
      <Td>
        <CreateTest e={e} />
      </Td>
      <Td>
        <Button size="sm" colorScheme="red" onClick={() => HandleDelete(e._id)}>
          Delete Data
        </Button>
      </Td>
    </Tr>
  );
};

export default TeacherTable;
